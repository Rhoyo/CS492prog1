package com.example.android.basicweather

data class WeatherF(
    val mon: String,
    val day: Int,
    val low: Int,
    val sDescript: String,
    val precip: Int,
    val high: Int,
    val lDescript: String,
)

val WData = listOf<WeatherF>(
    WeatherF(
        mon = "Jan",
        day = 3,
        low = 40,
        sDescript = "rainy day",
        precip = 99,
        high = 64,
        lDescript = "today will be a rainy day prepare for wet roads"
    ),
    WeatherF(
        mon = "Jan",
        day = 5,
        low = 31,
        sDescript = "chilly conditions",
        precip = 40,
        high = 49,
        lDescript = "icy conditions on roads from previous precipitation be careful"
    ),
    WeatherF(
        mon = "Jan",
        day = 8,
        low = 33,
        sDescript = "icy conditions",
        precip = 88,
        high = 50,
        lDescript = "today will be really rainy prepare for possible hail and wear a jacket"
    ),
    WeatherF(
        mon = "Jan",
        day = 12,
        low = 32,
        sDescript = "chilly conditions",
        precip = 55,
        high = 50,
        lDescript = "possible ice on the road be warned"
    ),
    WeatherF(
        mon = "Jan",
        day = 15,
        low = 39,
        sDescript = "icy conditions",
        precip = 82,
        high = 49,
        lDescript = "possible ice and snow on the road"
    ),
    WeatherF(
        mon = "Jan",
        day = 16,
        low = 54,
        sDescript = "sunny today",
        precip = 31,
        high = 72,
        lDescript = "rather sunny day go outside and enjoy it"
    ),
    WeatherF(
        mon = "Jan",
        day = 18,
        low = 39,
        sDescript = "icy conditions",
        precip = 82,
        high = 49,
        lDescript = "possible ice and snow on the road"
    ),
    WeatherF(
        mon = "Jan",
        day = 20,
        low = 39,
        sDescript = "snow and rain",
        precip = 80,
        high = 55,
        lDescript = "becareful dangerous conditions on the road"
    ),
    WeatherF(
        mon = "Jan",
        day = 22,
        low = 50,
        sDescript = "partly cloudy",
        precip = 31,
        high = 57,
        lDescript = "partly cloudy good day to go on a walk"
    ),
    WeatherF(
        mon= "Jan",
        day= 31,
        low= 27,
        sDescript= "snowy conditions",
        precip= 88,
        high= 44,
        lDescript= "possible ice on the road"
    )
    )