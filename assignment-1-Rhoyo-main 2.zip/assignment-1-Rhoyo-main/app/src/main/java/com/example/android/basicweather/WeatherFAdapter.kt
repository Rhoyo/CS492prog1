package com.example.android.basicweather

import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.TextView
import android.view.View
import com.google.android.material.snackbar.Snackbar
import androidx.recyclerview.widget.RecyclerView


class WeatherFAdapter(val items: List<WeatherF>):
        RecyclerView.Adapter<WeatherFAdapter.ViewHolder>() {
        override fun getItemCount() = items.size

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
                val view = LayoutInflater.from(parent.context)
                        .inflate(R.layout.weather_item, parent, false)
                return ViewHolder(view)
        }

        override fun onBindViewHolder(holder: WeatherFAdapter.ViewHolder, position: Int) {
                holder.bind(items[position])
        }

        inner class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
                private val monTV: TextView = view.findViewById(R.id.tv_mon)
                private val dayTV: TextView = view.findViewById(R.id.tv_day)
                private val sDescriptTV: TextView = view.findViewById(R.id.tv_sDescript)
                private val precipTV: TextView = view.findViewById(R.id.tv_precip)
                private val lowTV: TextView = view.findViewById(R.id.tv_low)
                private val highTV: TextView = view.findViewById(R.id.tv_high)

                fun bind(item: WeatherF) {
                        monTV.text = item.mon
                        dayTV.text = item.day.toString()
                        sDescriptTV.text = item.sDescript
                        lowTV.text = "${item.low}F"
                        highTV.text = "${item.high}F"
                        precipTV.text = "${item.precip}% precip"
                        itemView.setOnClickListener {
                                Snackbar.make(
                                        itemView,
                                        item.lDescript,
                                        Snackbar.LENGTH_LONG
                                ).show()
                        }
                }
        }
}