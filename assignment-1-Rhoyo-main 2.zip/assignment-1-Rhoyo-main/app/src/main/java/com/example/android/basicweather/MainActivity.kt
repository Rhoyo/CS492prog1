package com.example.android.basicweather

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val recyView = findViewById<RecyclerView>(R.id.rv_weatherF)
        val layoutManager = LinearLayoutManager(this)
        recyView.layoutManager = layoutManager
        recyView.setHasFixedSize(true)
        recyView.addItemDecoration(DividerItemDecoration(recyView.context, layoutManager.orientation))
        recyView.adapter = WeatherFAdapter(WData)
    }
}